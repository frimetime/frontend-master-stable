import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newnotification',
  templateUrl: './newnotification.component.html',
  styleUrls: ['./newnotification.component.scss'],
})
export class NewnotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
