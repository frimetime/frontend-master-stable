import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FrimelistPage } from './frimelist.page';

describe('FrimelistPage', () => {
  let component: FrimelistPage;
  let fixture: ComponentFixture<FrimelistPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FrimelistPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FrimelistPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
