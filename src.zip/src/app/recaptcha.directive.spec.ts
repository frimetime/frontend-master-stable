import { RecaptchaDirective } from './recaptcha.directive';

describe('RecaptchaDirective', () => {
  it('should create an instance', () => {
    const directive = new RecaptchaDirective();
    expect(directive).toBeTruthy();
  });
});
