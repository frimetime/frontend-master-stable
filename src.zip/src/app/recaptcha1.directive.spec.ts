import { Recaptcha1Directive } from './recaptcha1.directive';

describe('Recaptcha1Directive', () => {
  it('should create an instance', () => {
    const directive = new Recaptcha1Directive();
    expect(directive).toBeTruthy();
  });
});
