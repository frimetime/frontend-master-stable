import { Directive } from '@angular/core';

@Directive({
  selector: '[appRecaptcha1]'
})
export class Recaptcha1Directive {

  constructor() { }


}
