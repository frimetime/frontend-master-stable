export class Profile {
    id: number;
    username: string;
    email: string;
    country: string;
    role: string;
    sex: string;
    birthdate: string;
    image: string;
    description: string;
}
